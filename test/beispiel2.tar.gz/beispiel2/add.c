#include <stdio.h>
#include <libadd.h>

int main (void) 
{
  int c = add_it (3, 4);
  
  printf ("%s\n", "Hier ist das C-Programm. Berechne 3 + 4:");
  printf ("%d\n", c);

  return 0;
}
