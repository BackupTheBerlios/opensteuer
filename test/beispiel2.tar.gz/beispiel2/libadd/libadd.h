extern int add_it (int a, int b);
